# Support for Electron Packager

If you have questions about usage, we encourage you to read the [frequently asked
questions](https://github.com/electron-userland/electron-packager/blob/master/docs/faq.md),
and visit one of the several [community-driven sites](https://github.com/electron/electron#community).

Troubleshooting suggestions can be found in our [contributing
documentation](https://github.com/electron-userland/electron-packager/blob/master/CONTRIBUTING.md#debugging).
