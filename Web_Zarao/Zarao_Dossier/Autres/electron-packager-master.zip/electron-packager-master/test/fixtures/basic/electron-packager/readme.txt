This file exists to test ability to ignore paths under app, without also
ignoring the entire app folder due to a match above it (#54 / #55).
