## Collaborators

electron-packager is only possible due to the excellent work of the following collaborators:

<table><tbody><tr><th align="left">malept</th><td><a href="https://github.com/malept">GitHub/malept</a></td></tr>
<tr><th align="left">maxogden</th><td><a href="https://github.com/maxogden">GitHub/maxogden</a></td></tr>
<tr><th align="left">shama</th><td><a href="https://github.com/shama">GitHub/shama</a></td></tr>
<tr><th align="left">feross</th><td><a href="https://github.com/feross">GitHub/feross</a></td></tr>
<tr><th align="left">sindresorhus</th><td><a href="https://github.com/sindresorhus">GitHub/sindresorhus</a></td></tr>
<tr><th align="left">mafintosh</th><td><a href="https://github.com/mafintosh">GitHub/mafintosh</a></td></tr>
<tr><th align="left">kfranqueiro</th><td><a href="https://github.com/kfranqueiro">GitHub/kfranqueiro</a></td></tr>
<tr><th align="left">jden</th><td><a href="https://github.com/jden">GitHub/jden</a></td></tr>
<tr><th align="left">jlord</th><td><a href="https://github.com/jlord">GitHub/jlord</a></td></tr>
<tr><th align="left">stefanbuck</th><td><a href="https://github.com/stefanbuck">GitHub/stefanbuck</a></td></tr>
<tr><th align="left">remixz</th><td><a href="https://github.com/remixz">GitHub/remixz</a></td></tr>
</tbody></table>
